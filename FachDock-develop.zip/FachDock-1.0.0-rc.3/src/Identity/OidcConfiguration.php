<?php

declare(strict_types=1);

namespace FachDock\Identity;

use FachDock\Config\Config;
use RuntimeException;

final class OidcConfiguration
{
    public function __construct(private readonly Config $config)
    {
    }

    public function enabled(): bool
    {
        return $this->config->get('oidc.enabled', false) === true;
    }

    public function issuer(): string
    {
        return rtrim(trim((string) $this->config->get('oidc.issuer', '')), '/');
    }

    public function clientId(): string
    {
        return trim((string) $this->config->get('oidc.client_id', ''));
    }

    public function clientSecret(): string
    {
        return (string) $this->config->get('oidc.client_secret', '');
    }

    public function loginLabel(): string
    {
        $value = trim((string) $this->config->get('oidc.login_label', 'Mit OpenID Connect anmelden'));

        return $value !== '' ? mb_substr($value, 0, 80) : 'Mit OpenID Connect anmelden';
    }

    public function callbackUrl(): string
    {
        $base = rtrim(trim((string) $this->config->get('app.base_url', '')), '/');

        return $base === '' ? '' : $base . '/sso/callback';
    }

    public function scopes(): string
    {
        $value = trim((string) $this->config->get(
            'oidc.scopes',
            'openid profile email iserv:uuid iserv:groups iserv:roles iserv:untis',
        ));

        return $value !== '' ? $value : 'openid profile email';
    }

    /**
     * Legacy compatibility for installations that still contain student_auto_match.
     */
    public function studentAutoMatch(): string
    {
        $value = (string) $this->config->get('oidc.student_auto_match', 'email');

        return in_array($value, ['none', 'email', 'username_to_matrikelnummer'], true) ? $value : 'email';
    }

    public function studentMatchField(): string
    {
        $configured = $this->config->get('oidc.student_match_field');
        if (is_string($configured) && in_array($configured, ['none', 'email', 'matrikelnummer'], true)) {
            return $configured;
        }

        return match ($this->studentAutoMatch()) {
            'none' => 'none',
            'username_to_matrikelnummer' => 'matrikelnummer',
            default => 'email',
        };
    }

    public function studentMatchClaim(): string
    {
        $configured = trim((string) $this->config->get('oidc.student_match_claim', ''));
        if ($configured !== '' && preg_match('/^[A-Za-z0-9_.:-]{1,128}$/', $configured) === 1) {
            return $configured;
        }

        return $this->studentAutoMatch() === 'username_to_matrikelnummer'
            ? 'preferred_username'
            : 'email';
    }

    /** @return list<string> */
    public function studentRoleNames(): array
    {
        return $this->roleNames((string) $this->config->get('oidc.student_role_names', ''));
    }

    /** @return list<string> */
    public function teacherRoleNames(): array
    {
        return $this->roleNames((string) $this->config->get('oidc.teacher_role_names', 'Lehrer,Lehrkräfte'));
    }

    public function sessionLifetimeMinutes(): int
    {
        $value = $this->config->get('oidc.session_lifetime_minutes', 480);

        return is_numeric($value) ? min(10080, max(15, (int) $value)) : 480;
    }

    public function assertConfigured(): void
    {
        $issuer = $this->issuer();
        if (!$this->validHttpsUrl($issuer)) {
            throw new RuntimeException('Für OpenID Connect muss eine gültige HTTPS-Issuer-URL konfiguriert sein.');
        }
        if ($this->clientId() === '') {
            throw new RuntimeException('Die OpenID-Connect-Client-ID fehlt.');
        }
        if ($this->clientSecret() === '') {
            throw new RuntimeException('Das OpenID-Connect-Client-Geheimnis fehlt.');
        }
        if (!$this->validHttpsUrl($this->callbackUrl())) {
            throw new RuntimeException('Die öffentliche FachDock-Basis-URL muss für OpenID Connect als HTTPS-URL konfiguriert sein.');
        }
    }

    public function assertReady(): void
    {
        if (!$this->enabled()) {
            throw new RuntimeException('Die OpenID-Connect-Anmeldung ist nicht aktiviert.');
        }
        $this->assertConfigured();
    }

    public function ready(): bool
    {
        try {
            $this->assertReady();

            return true;
        } catch (RuntimeException) {
            return false;
        }
    }

    /** @return list<string> */
    private function roleNames(string $raw): array
    {
        $result = [];
        foreach (preg_split('/[,;\n]+/', $raw) ?: [] as $role) {
            $role = mb_strtolower(trim($role));
            if ($role !== '' && !in_array($role, $result, true)) {
                $result[] = $role;
            }
        }

        return $result;
    }

    private function validHttpsUrl(string $url): bool
    {
        return filter_var($url, FILTER_VALIDATE_URL) !== false
            && strtolower((string) parse_url($url, PHP_URL_SCHEME)) === 'https';
    }
}
