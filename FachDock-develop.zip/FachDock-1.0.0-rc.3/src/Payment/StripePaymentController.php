<?php

declare(strict_types=1);

namespace FachDock\Payment;

use DomainException;
use FachDock\Audit\AuditLogger;
use FachDock\Http\Request;
use FachDock\Http\Response;
use FachDock\Http\Router;
use FachDock\Mail\BookingNotificationService;
use FachDock\Parent\AuthenticatedParent;
use FachDock\Parent\ParentSessionService;
use FachDock\Security\Csrf;
use FachDock\View\ViewRenderer;
use Psr\Log\LoggerInterface;
use Stripe\Exception\SignatureVerificationException;
use Throwable;
use UnexpectedValueException;

final class StripePaymentController
{
    private const CHECKOUT_HANDOFF_KEY = 'stripe_checkout_handoff';

    public function __construct(
        private readonly StripePaymentService $payments,
        private readonly BookingDueStripePaymentService $bookingPayments,
        private readonly BookingNotificationService $notifications,
        private readonly ParentSessionService $sessions,
        private readonly AuditLogger $audit,
        private readonly LoggerInterface $logger,
        private readonly ViewRenderer $views,
        private readonly Csrf $csrf,
    ) {
    }

    public function register(Router $router): void
    {
        $router->post('/parent/payment/start', fn (Request $request): Response => $this->start($request));
        $router->get('/parent/payment/continue', fn (Request $request): Response => $this->continueCheckout($request));
        $router->get('/parent/payment/return', fn (Request $request): Response => $this->returnFromStripe($request));
        $router->post('/webhooks/stripe', fn (Request $request): Response => $this->webhook($request));
    }

    private function start(Request $request): Response
    {
        $parent = $this->parent();
        if ($parent instanceof Response) {
            return $parent;
        }
        if (!$this->csrf->verify($request->postString('_csrf'))) {
            return Response::html('<h1>Ungültige Sitzung</h1>', 419);
        }

        try {
            $bookingValue = trim($request->postString('booking_id'));
            if ($bookingValue !== '') {
                $bookingId = $this->positiveInt($bookingValue, 'Buchung');
                $result = $this->bookingPayments->start($parent, $bookingId);
                $this->audit->parent($parent, 'payment.stripe_booking_checkout.started', 'payment', $result->paymentId, [
                    'booking_id' => $bookingId,
                ]);

                return $this->checkoutHandoff($parent, $result->checkoutUrl());
            }

            $reservationId = $this->positiveInt($request->postString('reservation_id'), 'Reservierung');
            $result = $this->payments->start($parent, $reservationId);

            if ($result->bookingId !== null) {
                $this->audit->parent($parent, 'payment.no_fee_booking.created', 'booking', $result->bookingId, [
                    'reservation_id' => $reservationId,
                ]);
                $this->notifications->bookingConfirmed($result->bookingId);

                return Response::redirect('/parent?booking_created=1');
            }

            $this->audit->parent($parent, 'payment.stripe_checkout.started', 'payment', $result->paymentId, [
                'reservation_id' => $reservationId,
            ]);

            return $this->checkoutHandoff($parent, $result->checkoutUrl());
        } catch (DomainException $exception) {
            return $this->errorPage($parent, $exception->getMessage(), 422);
        } catch (Throwable $exception) {
            $errorId = bin2hex(random_bytes(6));
            $this->logger->error('Stripe checkout start failed', [
                'error_id' => $errorId,
                'parent_contact_id' => $parent->id,
                'exception' => $exception,
            ]);

            return $this->errorPage(
                $parent,
                'Der Zahlungsvorgang konnte nicht gestartet werden. Fehler-ID: ' . $errorId,
                500,
            );
        }
    }

    private function continueCheckout(Request $request): Response
    {
        unset($request);
        $parent = $this->parent();
        if ($parent instanceof Response) {
            return $parent;
        }

        $handoff = $_SESSION[self::CHECKOUT_HANDOFF_KEY] ?? null;
        unset($_SESSION[self::CHECKOUT_HANDOFF_KEY]);
        if (!is_array($handoff)) {
            return $this->errorPage($parent, 'Der Stripe-Zahlungsübergang ist nicht mehr gültig. Bitte starten Sie die Zahlung erneut.', 422);
        }

        $parentId = $handoff['parent_contact_id'] ?? null;
        $checkoutUrl = $handoff['checkout_url'] ?? null;
        $expiresAt = $handoff['expires_at'] ?? null;
        if (!is_int($parentId) || $parentId !== $parent->id
            || !is_string($checkoutUrl) || !$this->validCheckoutUrl($checkoutUrl)
            || !is_int($expiresAt) || $expiresAt < time()) {
            return $this->errorPage($parent, 'Der Stripe-Zahlungsübergang ist ungültig oder abgelaufen. Bitte starten Sie die Zahlung erneut.', 422);
        }

        return Response::redirect($checkoutUrl);
    }

    private function returnFromStripe(Request $request): Response
    {
        $parent = $this->parent();
        if ($parent instanceof Response) {
            return $parent;
        }

        try {
            $paymentId = $this->positiveInt($this->queryString($request, 'payment_id'), 'Zahlung');
            $payment = $this->payments->paymentForParent($parent, $paymentId);

            return Response::html($this->views->render('parent-payment.php', [
                'parent' => $parent,
                'payment' => $payment,
                'csrfToken' => $this->csrf->token(),
                'error' => null,
            ]));
        } catch (DomainException $exception) {
            return $this->errorPage($parent, $exception->getMessage(), 422);
        } catch (Throwable $exception) {
            $errorId = bin2hex(random_bytes(6));
            $this->logger->error('Stripe payment return page failed', [
                'error_id' => $errorId,
                'parent_contact_id' => $parent->id,
                'exception' => $exception,
            ]);

            return $this->errorPage(
                $parent,
                'Der Zahlungsstatus konnte nicht geladen werden. Fehler-ID: ' . $errorId,
                500,
            );
        }
    }

    private function webhook(Request $request): Response
    {
        try {
            $payload = $request->rawBody();
            $signature = $request->header('Stripe-Signature');
            if (!$this->bookingPayments->handleWebhookIfBookingPayment($payload, $signature)) {
                $this->payments->handleWebhook($payload, $signature);
            }
            $this->notifications->stripeEventProcessed($payload);

            return Response::text('ok');
        } catch (SignatureVerificationException|UnexpectedValueException|DomainException $exception) {
            $this->logger->notice('Stripe webhook rejected', [
                'message' => $exception->getMessage(),
            ]);

            return Response::text('invalid webhook', 'text/plain; charset=utf-8', 400);
        } catch (Throwable $exception) {
            $errorId = bin2hex(random_bytes(6));
            $this->logger->error('Stripe webhook processing failed', [
                'error_id' => $errorId,
                'exception' => $exception,
            ]);

            return Response::text('webhook processing failed', 'text/plain; charset=utf-8', 500);
        }
    }

    private function parent(): AuthenticatedParent|Response
    {
        $parent = $this->sessions->current();
        if ($parent === null) {
            return Response::redirect('/parent/login');
        }

        return $parent;
    }

    private function checkoutHandoff(AuthenticatedParent $parent, string $checkoutUrl): Response
    {
        if (!$this->validCheckoutUrl($checkoutUrl)) {
            throw new DomainException('Stripe hat keine gültige HTTPS-Checkout-Adresse geliefert.');
        }

        $_SESSION[self::CHECKOUT_HANDOFF_KEY] = [
            'parent_contact_id' => $parent->id,
            'checkout_url' => $checkoutUrl,
            'expires_at' => time() + 300,
        ];

        $continueUrl = '/parent/payment/continue';

        return Response::html(
            '<!doctype html><html lang="de"><head><meta charset="utf-8">'
            . '<meta name="viewport" content="width=device-width, initial-scale=1">'
            . '<meta http-equiv="refresh" content="0;url=' . $continueUrl . '">'
            . '<title>Zahlung starten · FachDock</title></head><body>'
            . '<main><h1>Zahlung wird gestartet</h1>'
            . '<p>Sie werden zur sicheren Stripe-Zahlungsseite weitergeleitet.</p>'
            . '<p><a href="' . $continueUrl . '">Weiter zu Stripe</a></p>'
            . '</main></body></html>',
        );
    }

    private function validCheckoutUrl(string $url): bool
    {
        if (filter_var($url, FILTER_VALIDATE_URL) === false) {
            return false;
        }

        $parts = parse_url($url);

        return is_array($parts)
            && strtolower((string) ($parts['scheme'] ?? '')) === 'https'
            && trim((string) ($parts['host'] ?? '')) !== '';
    }

    private function errorPage(AuthenticatedParent $parent, string $message, int $status): Response
    {
        return Response::html($this->views->render('parent-payment.php', [
            'parent' => $parent,
            'payment' => null,
            'csrfToken' => $this->csrf->token(),
            'error' => $message,
        ]), $status);
    }

    private function positiveInt(string $value, string $label): int
    {
        if (preg_match('/^\d+$/', trim($value)) !== 1 || (int) $value < 1) {
            throw new DomainException($label . ' ist ungültig.');
        }

        return (int) $value;
    }

    private function queryString(Request $request, string $key): string
    {
        $value = $request->query()[$key] ?? '';

        return is_scalar($value) ? trim((string) $value) : '';
    }
}
