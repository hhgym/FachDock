<?php

declare(strict_types=1);

use FachDock\Application;
use FachDock\Auth\StaffUserAdminFrontController;
use FachDock\Booking\BookingDocumentFrontController;
use FachDock\Booking\BookingRulesFrontController;
use FachDock\Booking\ParentBookingMapFrontController;
use FachDock\Dashboard\DashboardFrontController;
use FachDock\Identity\IdentityFrontController;
use FachDock\Identity\OidcAdminFrontController;
use FachDock\Identity\PersonAccountAdminFrontController;
use FachDock\Mail\MailImmediateAdminFrontController;
use FachDock\Operations\OperationsFrontController;
use FachDock\Payment\PaymentAdminActionFrontController;
use FachDock\Payment\StripePaymentResumeFrontController;
use FachDock\Payment\StripeReturnFrontController;
use FachDock\Platform\PlatformFrontController;

$root = dirname(__DIR__);
$autoload = $root . '/vendor/autoload.php';

if (!is_file($autoload)) {
    http_response_code(503);
    header('Content-Type: text/plain; charset=utf-8');
    echo "FachDock dependencies are missing. Install the release package or run Composer.\n";
    exit;
}

require $autoload;

$dashboardResponse = DashboardFrontController::handle($root);
if ($dashboardResponse !== null) {
    $dashboardResponse->send();
    exit;
}

$mailImmediateResponse = MailImmediateAdminFrontController::handle($root);
if ($mailImmediateResponse !== null) {
    $mailImmediateResponse->send();
    exit;
}

$paymentAdminActionResponse = PaymentAdminActionFrontController::handle($root);
if ($paymentAdminActionResponse !== null) {
    $paymentAdminActionResponse->send();
    exit;
}

$stripeReturnResponse = StripeReturnFrontController::handle($root);
if ($stripeReturnResponse !== null) {
    $stripeReturnResponse->send();
    exit;
}

$stripePaymentResumeResponse = StripePaymentResumeFrontController::handle($root);
if ($stripePaymentResumeResponse !== null) {
    $stripePaymentResumeResponse->send();
    exit;
}

$bookingDocumentResponse = BookingDocumentFrontController::handle($root);
if ($bookingDocumentResponse !== null) {
    $bookingDocumentResponse->send();
    exit;
}

$oidcAdminResponse = OidcAdminFrontController::handle($root);
if ($oidcAdminResponse !== null) {
    $oidcAdminResponse->send();
    exit;
}

$personAccountResponse = PersonAccountAdminFrontController::handle($root);
if ($personAccountResponse !== null) {
    $personAccountResponse->send();
    exit;
}

$staffUserAdminResponse = StaffUserAdminFrontController::handle($root);
if ($staffUserAdminResponse !== null) {
    $staffUserAdminResponse->send();
    exit;
}

$identityResponse = IdentityFrontController::handle($root);
if ($identityResponse !== null) {
    $identityResponse->send();
    exit;
}

$bookingRulesResponse = BookingRulesFrontController::handle($root);
if ($bookingRulesResponse !== null) {
    $bookingRulesResponse->send();
    exit;
}

$bookingMapResponse = ParentBookingMapFrontController::handle($root);
if ($bookingMapResponse !== null) {
    $bookingMapResponse->send();
    exit;
}

$platformResponse = PlatformFrontController::handle($root);
if ($platformResponse !== null) {
    $platformResponse->send();
    exit;
}

$operationsResponse = OperationsFrontController::handle($root);
if ($operationsResponse !== null) {
    $operationsResponse->send();
    exit;
}

Application::boot($root)->run();
